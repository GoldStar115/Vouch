//
//  VOSearchViewController.h
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <REFrostedViewController.h>
@interface VOSearchViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *leftmenuBtn;
@property NSMutableArray *arrayVouchs;
@property (weak, nonatomic) IBOutlet UIImageView *imageBackground;
@property (weak, nonatomic) IBOutlet UIImageView *imageLikePhoto;
@property (weak, nonatomic) IBOutlet UILabel *lblMutaualNumber;
@property (weak, nonatomic) IBOutlet UIButton *btnLike;
@property (weak, nonatomic) IBOutlet UIButton *btnDislike;
@property (weak, nonatomic) IBOutlet UILabel *lblVouchesNumber;
@property (weak, nonatomic) IBOutlet UIButton *btnGetVouches;
@property (weak, nonatomic) IBOutlet UILabel *lblDescription;
- (void)panGestureRecognized:(UIPanGestureRecognizer *)sender;
@end
