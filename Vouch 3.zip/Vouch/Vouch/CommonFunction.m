//
//  CommonFunction.m
//  Vouch
//
//  Created by My Star on 4/25/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "CommonFunction.h"

@implementation CommonFunction
+(NSString *)getDeviceID{
    NSString *UDID;
    UDID = [[[UIDevice currentDevice] identifierForVendor] UUIDString]; // IOS 6+
    NSLog(@"output is : %@", UDID);
    return UDID;
}

+ (void)saveSessionID:(NSString *) sessionID{
    
    [[NSUserDefaults standardUserDefaults] setObject:sessionID forKey:USER_SESSION_ID];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
}
+ (void)saveUserID:(NSString *) userID{
    
    [[NSUserDefaults standardUserDefaults] setObject:userID forKey:USER_ID];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
}
+ (NSString *)getSessionID{
    NSLog(@"%@",[[NSUserDefaults standardUserDefaults]
                 stringForKey:USER_SESSION_ID] );
    return [[NSUserDefaults standardUserDefaults]
            stringForKey:USER_SESSION_ID];
}
+ (NSString *)getUserID{
    NSLog(@"%@",[[NSUserDefaults standardUserDefaults]
                 stringForKey:USER_ID] );
    return [[NSUserDefaults standardUserDefaults]
            stringForKey:USER_ID];
}

+(CommonFunction *) sharedAppDelegate
{
    CommonFunction  *delegate = (CommonFunction *) [[UIApplication sharedApplication] delegate];
    return delegate;
}
+ (void)resetDefaults {
    NSUserDefaults * defs = [NSUserDefaults standardUserDefaults];
    NSDictionary * dict = [defs dictionaryRepresentation];
    for (id key in dict) {
        [defs removeObjectForKey:key];
    }
    [defs synchronize];
}
@end
