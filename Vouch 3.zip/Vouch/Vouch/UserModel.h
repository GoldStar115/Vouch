//
//  UserModel.h
//  Vouch
//
//  Created by My Star on 4/22/16.
//  Copyright © 2016 Vouch. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <JSONModel/JSONModel.h>
@interface UserModel : JSONModel
@property NSNumber<Optional> *__v;// = 0;
@property NSMutableString<Optional> *_id;//"_id" = 201139893595375;
@property NSNumber<Optional> *active;//active = 1;
@property NSString<Optional> *age_range;// "age_range" = 1;
@property NSString<Optional> *email;
@property NSArray<Optional> *friends;
@property NSString<Optional> *gender;
@property NSMutableString<Optional> *last_likes_reset;
@property NSMutableString<Optional> *last_login;
@property NSNumber<Optional> *likes_since_reset;
@property NSArray<Optional> *matches;
@property NSString<Optional> *name;
@property NSMutableString<Optional> *profile_picture_url;
@property NSArray<Optional> *likes;
@end
