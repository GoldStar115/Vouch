//
//  MenuViewController.m
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "MenuViewController.h"
#import "LeftMenuNavigationViewController.h"
#import "VOSearchViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "AppDelegate.h"
@interface MenuViewController ()
@end

@implementation MenuViewController

- (void) viewDidLoad{
    UIGraphicsBeginImageContext(self.view.frame.size);
    [self configureLabelSlider];
    [[UIImage imageNamed:@"background"] drawInRect:self.view.bounds];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();    
    self.view.backgroundColor = [UIColor colorWithPatternImage:image];
    if ([AppDelegate sharedAppDelegate].profile_picture_url) {
            [_imagePhoto1 sd_setImageWithURL:[NSURL URLWithString:[AppDelegate sharedAppDelegate].profile_picture_url] placeholderImage:[UIImage imageNamed:@"samplephoto"]];
            [_imageSubPhoto2 sd_setImageWithURL:[NSURL URLWithString:[AppDelegate sharedAppDelegate].profile_picture_url] placeholderImage:[UIImage imageNamed:@"samplephoto"]];
            [_imageSubPhoto3 sd_setImageWithURL:[NSURL URLWithString:[AppDelegate sharedAppDelegate].profile_picture_url] placeholderImage:[UIImage imageNamed:@"samplephoto"]];
            [_imagesubPhoto4 sd_setImageWithURL:[NSURL URLWithString:[AppDelegate sharedAppDelegate].profile_picture_url] placeholderImage:[UIImage imageNamed:@"samplephoto"]];
    }else{
           [_imagePhoto1 sd_setImageWithURL:[NSURL URLWithString:[AppDelegate sharedAppDelegate].profile_picture_url] placeholderImage:[UIImage imageNamed:@"samplephoto"]];
    }

}
#pragma mark - Label  Slider

- (void) configureLabelSlider
{
    self.SliderAgeRange.minimumValue = 0;
    self.SliderAgeRange.maximumValue = 100;
    
    self.SliderAgeRange.lowerValue = 0;
    self.SliderAgeRange.upperValue = 100;
    
    self.SliderAgeRange.minimumRange = 10;
}






@end
