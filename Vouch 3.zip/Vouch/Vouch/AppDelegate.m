//
//  AppDelegate.m
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "AppDelegate.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    self.menuView = (MenuViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"menuViewController"];
    [SlideNavigationController sharedInstance].leftMenu = self.menuView;
    [SlideNavigationController sharedInstance].portraitSlideOffset = 55;
    [SlideNavigationController sharedInstance].landscapeSlideOffset = 55;
    [SlideNavigationController sharedInstance].enableSwipeGesture = YES;
    [SlideNavigationController sharedInstance].enableShadow = YES;
    
    
    [[FBSDKApplicationDelegate sharedInstance] application:application
                             didFinishLaunchingWithOptions:launchOptions];

    [self init_value];
    return YES;
}
#pragma mark variable init
- (void)init_value{
    self.isLogin = false;
    self.savedUserID = @"";
    self.users = [[UserModel alloc] init];
    self.profile_picture_url = @"";
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    [FBSDKAppEvents activateApp];
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}
#pragma mark facebook integration.

- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation {
    return [[FBSDKApplicationDelegate sharedInstance] application:application
                                                          openURL:url
                                                sourceApplication:sourceApplication
                                                       annotation:annotation];
}
#pragma mark - Indicator views

+(AppDelegate *) sharedAppDelegate
{
    AppDelegate  *delegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    return delegate;
}


- (void)showWaitingScreen:(NSString *)strText bShowText:(BOOL)bShowText withSize : (CGSize) size
{
    
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    
    [view setTag:TAG_WAIT_SCREEN_VIEW];
    [view setBackgroundColor:[UIColor clearColor]];
    [view setAlpha:1.0f];
    
    if (bShowText) {
        UIView *subView = [[UIView alloc] init];
        [subView setBackgroundColor:[UIColor blackColor]];
        [subView setAlpha:0.7];
        
        int width = size.width;
        int height = size.height;
        
        [subView setFrame:CGRectMake(view.frame.size.width/2-width/2, view.frame.size.height/2-height/2, width, height)];
        
        UIActivityIndicatorView *indicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        [indicatorView setTag:TAG_WAIT_SCREEN_INDICATOR];
        
        CGRect rectIndicatorViewFrame = [indicatorView frame];
        
        width = rectIndicatorViewFrame.size.width;
        height = rectIndicatorViewFrame.size.height;
        
        [indicatorView setFrame:CGRectMake(subView.frame.size.width/2-width/2, subView.frame.size.height/3-width/2, width, height)];
        
        [indicatorView startAnimating];
        [subView addSubview:indicatorView];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, subView.frame.size.height*2/3, subView.frame.size.width, subView.frame.size.height/3)];
        [label setText:strText];
        
        [label setBackgroundColor:[UIColor clearColor]];
        [label setTextAlignment:NSTextAlignmentCenter];
        
        [label setTextColor:[UIColor whiteColor]];
        [label setTag:TAG_WAIT_SCREEN_LABEL];
        
        [label setFont:[UIFont fontWithName:@"Caflisch Script Web" size:17 * MULTIPLY_VALUE]];
        
        [subView addSubview:label];
        subView.layer.cornerRadius = 10.0f;//  = [Common roundCornersOnView:subView onTopLeft:YES topRight:YES bottomLeft:YES bottomRight:YES radius:10.0f];
        
        [view addSubview:subView];
    }
    
    [_window addSubview:view];
}

- (void)hideWaitingScreen {
    
    UIView *view = [_window viewWithTag:TAG_WAIT_SCREEN_VIEW];    
    if (view) {
        UIActivityIndicatorView *indicatorView = (UIActivityIndicatorView*)[view viewWithTag:TAG_WAIT_SCREEN_INDICATOR];
        if (indicatorView)
            [indicatorView stopAnimating];
        [view removeFromSuperview];
        UILabel *label = (UILabel *)[view viewWithTag:TAG_WAIT_SCREEN_LABEL];
        if (label) {
            [label removeFromSuperview];
        }
    }
}

@end
