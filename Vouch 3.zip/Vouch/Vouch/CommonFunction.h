//
//  CommonFunction.h
//  Vouch
//
//  Created by My Star on 4/25/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
////////////////////////////////Session_TAG///////////////
#define USER_SESSION_ID @"session_id"
#define USER_ID @"user_id"

@interface CommonFunction : NSObject
+(NSString *)getDeviceID;
+ (void)saveSessionID:(NSString *) sessionID;
+ (void)saveUserID:(NSString *) userID;
+ (NSString *)getSessionID;
+ (NSString *)getUserID;
+ (void)resetDefaults ;
+(CommonFunction *) sharedAppDelegate;
@end
