//
//  AppDelegate.h
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//
#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define IS_IPHONE_5 (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 568.0f)
#define IS_RETINA ([[UIScreen mainScreen] scale] == 2.0f)

#define SCREEN_WIDTH   [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT   [[UIScreen mainScreen] bounds].size.height

#define MULTIPLY_VALUE          (IS_IPAD ? 2.0 : 1.0)
///////////////////////////////////////////////////////////////////////////////////

#define TAG_WAIT_SCREEN_VIEW            1025
#define TAG_WAIT_SCREEN_INDICATOR       1026
#define TAG_WAIT_SCREEN_LABEL           1027





#import <UIKit/UIKit.h>
#import "MenuViewController.h"
#import "VOMatchViewController.h"
#import "SlideNavigationController.h"
#import "UserModel.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property BOOL isLogin;
@property (strong, nonatomic) UIWindow *window;
@property UserModel *users;
@property MenuViewController *menuView;

@property NSString * savedUserID;
@property NSString *profile_picture_url;
+(AppDelegate *) sharedAppDelegate;
- (void)showWaitingScreen:(NSString *)strText bShowText:(BOOL)bShowText withSize : (CGSize) size;
- (void)hideWaitingScreen;

@end

