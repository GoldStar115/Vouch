//
//  VOMatchViewController.m
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "VOMatchViewController.h"
#import "VODetailViewController.h"
#import "ApiService.h"
#import "AppDelegate.h"
#import "CommonFunction.h"
#import "UserJSONModel.h"
#import "UserModel.h"
#import "SessionModel.h"
#import "CustomMatchCollectionCell.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "VOSearchViewController.h"
#import <FBSDKLoginKit/FBSDKLoginManagerLoginResult.h>
#import <FBSDKLoginKit/FBSDKLoginManager.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <FBSDKCoreKit/FBSDKGraphRequest.h>
#import <FBSDKAccessToken.h>

@interface VOMatchViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>
{
    NSMutableArray *arraySelected;
    NSIndexPath *selectedRow;
}
@end

@implementation VOMatchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.collectionView.backgroundColor = [UIColor clearColor];
    self.collectionView.allowsMultipleSelection = YES;
    self.collectionView.allowsSelection = YES;
    arraySelected  = [NSMutableArray array];
}
- (void) viewWillAppear:(BOOL)animated
{
    [[AppDelegate sharedAppDelegate] showWaitingScreen:@"Loading..." bShowText:YES withSize:CGSizeMake(150 * MULTIPLY_VALUE, 100 * MULTIPLY_VALUE)];
    NSLog(@"UserTestID = %@",[CommonFunction getUserID]);
    [ApiService getUser:USER_GET_URI withUserID:[CommonFunction getUserID] withCompletion:^(UserModel *userJSONModel){
        [[AppDelegate sharedAppDelegate] hideWaitingScreen];
        ////imageLoad/////
        [_imgMainPhoto sd_setImageWithURL:[NSURL URLWithString:userJSONModel.profile_picture_url]
                         placeholderImage:[UIImage imageNamed:@"samplephoto"]];
        _labMainName.text = userJSONModel.name;
        _lblMainAge.text = [[[NSString stringWithFormat:@"%@",userJSONModel.age_range] componentsSeparatedByString:@"-"] objectAtIndex:0];
        
        _friendListArray = [NSMutableArray arrayWithArray:userJSONModel.friends];
        [self.collectionView reloadData];

        
    } failure:^(NSError *error) {
        [[AppDelegate sharedAppDelegate] hideWaitingScreen];
        NSLog(@"GetUser_Failed = %@",error);
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)onBackMatch:(id)sender {
  
}
- (IBAction)onBackHomeView:(id)sender {

}
-(NSInteger)numberOfSectionsInCollectionView:
(UICollectionView *)collectionView
{
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    if (_friendListArray) {
        NSLog(@"Count  =  %d",(int)_friendListArray.count);
        return _friendListArray.count;
    }else{
        return 0;
    }
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CustomMatchCollectionCell *customCell = [collectionView
                                    dequeueReusableCellWithReuseIdentifier:@"customCell"
                                    forIndexPath:indexPath];
    if (customCell == nil) {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CustomMatchCollectionCell" owner:self options:nil];
        customCell = [nib objectAtIndex:0];
    }
    NSString *tempURLString = [[_friendListArray[indexPath.row] componentsSeparatedByString:@" = "] objectAtIndex:2];
    [customCell.imgPhoto sd_setImageWithURL:[NSURL URLWithString:tempURLString] placeholderImage:[UIImage imageNamed:@"samplephoto"]];
    customCell.imgPhoto.layer.backgroundColor=[[UIColor clearColor] CGColor];
    customCell.imgPhoto.layer.cornerRadius=15.0f;
    customCell.imgPhoto.clipsToBounds = YES;
    customCell.imgPhoto.layer.borderColor=[[UIColor brownColor] CGColor];
    if ([arraySelected indexOfObject:[NSNumber numberWithInteger:indexPath.row]] == NSNotFound) {
        customCell.imgSelectedShow.image  = nil;
        customCell.lblinviteName.text = [[_friendListArray[indexPath.row] componentsSeparatedByString:@" = "] objectAtIndex:1];
    }
    else{
        customCell.imgSelectedShow.image = [UIImage imageNamed:@"match"];
        customCell.lblinviteName.text = @"Invited";
    }

    return customCell;
}
- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(CustomMatchCollectionCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
    
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    CustomMatchCollectionCell *customDidSelectedCell = (CustomMatchCollectionCell *)[collectionView cellForItemAtIndexPath:indexPath];
     customDidSelectedCell.imgSelectedShow.image = [UIImage imageNamed:@"match"];
     customDidSelectedCell.lblinviteName.text = @"Invited";
     selectedRow = indexPath;
    if ([arraySelected indexOfObject:[NSNumber numberWithInteger:indexPath.row]] == NSNotFound) {
        [arraySelected addObject:[NSNumber numberWithInteger:indexPath.row]];
    } else {
        [arraySelected removeObject:[NSNumber numberWithInteger:indexPath.row]];
    }
}
- (void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath{
    CustomMatchCollectionCell *customDidSelectedCell = (CustomMatchCollectionCell *)[collectionView cellForItemAtIndexPath:indexPath];
    customDidSelectedCell.imgSelectedShow.image = nil;
    customDidSelectedCell.lblinviteName.text = [[_friendListArray[indexPath.row] componentsSeparatedByString:@" = "] objectAtIndex:1];
    selectedRow = indexPath;
    if ([arraySelected indexOfObject:[NSNumber numberWithInteger:indexPath.row]] == NSNotFound) {
        [arraySelected addObject:[NSNumber numberWithInteger:indexPath.row]];
    } else {
        [arraySelected removeObject:[NSNumber numberWithInteger:indexPath.row]];
    }
}
- (IBAction)onVouchRequest:(id)sender {
    if(arraySelected.count < 5)
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Please select friens more than 5" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
    }else{
        
        if (!arraySelected.count) {
            [[[UIAlertView alloc] initWithTitle:@"Warning!" message:@"Please choose images." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
            return;
        }
        NSMutableArray * tmpArray = [NSMutableArray array];
        for (NSNumber * index in arraySelected) {
            NSString * model = _friendListArray[index.integerValue];
            if (model) {
                [tmpArray addObject:model];
            }
        }
        VOSearchViewController * viewController = [self.storyboard instantiateViewControllerWithIdentifier:@"searchViewController"];
        viewController.arrayVouchs = [NSMutableArray array];
        viewController.arrayVouchs = tmpArray;
        [self.navigationController pushViewController:viewController animated:YES];
    }
}
- (IBAction)onLogOut:(id)sender {
    FBSDKLoginManager *loginManager = [[FBSDKLoginManager alloc] init];
    [loginManager logOut];
    [FBSDKAccessToken setCurrentAccessToken:nil];
    [CommonFunction resetDefaults];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
