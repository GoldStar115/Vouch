//
//  ApiService.h
//  Vouch
//
//  Created by My Star on 4/22/16.
//  Copyright © 2016 Vouch. All rights reserved.
//
////////////////////////////////USERMODEL_TAG///////////////////////////////////////////////////
#define USERID @"id"//: facebook id
#define USERNAME @"name"
#define USEREMAIL @"email"
#define USER_AGE  @"age_range"
#define USERGENDER @"gender"
#define USERPROFILEIMGET @"profile_picture_url"
#define USERFRIENDS @"friends"
////////////////////////////////URL_TAG///////////////////////////////////
#define USER_CREAT_URI @"users"
#define USER_GET_URI @"users"
#define USER_DELETE_URI @"users"
#define USER_CREAT_SESSION_URI @"sessions"
#define USER_WAITINGLIST_URI @"waitinglist"
#define USER_VOUCH_URI @"vouches"
#define USER_LIKES_URI @"likes"
#define USER_RATING_URI @"ratings"

#define VOUCH_BASE_URL @"https://vouch-web.herokuapp.com/api/"

#import <Foundation/Foundation.h>
#import <AFHTTPSessionManager.h>
#import <AFURLRequestSerialization.h>
#import "UserJSONModel.h"
#import "SessionModel.h"

@interface ApiService : NSObject

#pragma mark user
+ (void)creatUser:(NSString *)creatUserUri withJsonUserData:(NSDictionary *)userModel withCompletion:(void (^)(BOOL success_flag))completion  failure:(void (^)(NSError * error))failure;
+ (void)getUser:(NSString *)getUserUri withUserID:(NSString *)userID withCompletion:(void (^)(UserModel *userJSONModel))completion  failure:(void (^)(NSError * error))failure;
+ (void)userDelete:(NSString *)deleteUserUri withUserID:(NSString *)userID withCompletion:(void (^)(BOOL delete_flag))completion  failure:(void (^)(NSError * error))failure;
+ (void)creatSession:(NSString *)creatUserSessionUri withUserID:(NSString *)userID withDeviceID:(NSString *)deviceID withCompletion:(void (^)(SessionModel *sessionModel))completion  failure:(void (^)(NSError * error))failure;

#pragma mark session
+ (void)updateSession:(NSString *)updateUserSessionUri withUserSessionID:(NSString *)userSessionID withCompletion:(void (^)(BOOL updateSessionFlag))completion  failure:(void (^)(NSError * error))failure;
+ (void)deleteSession:(NSString *)deleteUserSessionUri withUserSessionID:(NSString *)userSessionID withCompletion:(void (^)(BOOL updateSessionFlag))completion  failure:(void (^)(NSError * error))failure;

#pragma mark waitingList
+ (void)creatwaitingList:(NSString *)waitingListUri withUserEmail:(NSString *)userEmail withCompletion:(void (^)(BOOL waitinglistSuccess_flag))completion  failure:(void (^)(NSError * error))failure;
+ (void)deletewaitingList:(NSString *)waitingListUri withUserEmail:(NSString *)userEmail withCompletion:(void (^)(BOOL waitinglistSuccess_flag))completion  failure:(void (^)(NSError * error))failure;

#pragma mark vouches

+ (void)getVouchUser:(NSString *)getVouchUri withUserID:(NSString *)userID withCompletion:(void (^)(NSString * vouchUserID))completion  failure:(void (^)(NSError * error))failure;
+ (void)updateVouchUser:(NSString *)postVouchUri withSessinID:(NSString *) giverSessionID withReceiverUserID :(NSString *)receiverUserID withCompletion:(void (^)(NSString * vouchUserID))completion  failure:(void (^)(NSError * error))failure;

#pragma mark Like
+ (void)postLikeUser:(NSString *)postLikeUri withLikerID:(NSString *)likerId withLikedID:(NSString *)likedId withCompletion:(void (^)(BOOL match_flag))completion  failure:(void (^)(NSError * error))failure;

#pragma mark ratings
+ (void)postRatingsUser:(NSString *)postRatingUri withUserID:(NSString *)user_id withRating:(NSString *)rating withCompletion:(void (^)(BOOL rating_flag))completion  failure:(void (^)(NSError * error))failure;
@end
