//
//  CustomMatchCollectionCell.h
//  Vouch
//
//  Created by My Star on 4/26/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomMatchCollectionCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgPhoto;
@property (weak, nonatomic) IBOutlet UIImageView *imgSelectedShow;
@property (weak, nonatomic) IBOutlet UILabel *lblinviteName;

@end
