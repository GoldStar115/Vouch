//
//  ViewController.m
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "VOLoginViewController.h"
#import "AppDelegate.h"
#import <FBSDKLoginKit/FBSDKLoginManagerLoginResult.h>
#import <FBSDKLoginKit/FBSDKLoginManager.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <FBSDKCoreKit/FBSDKGraphRequest.h>
#import <FBSDKAccessToken.h>
#import "UserModel.h"
#import "ApiService.h"
#import "VOSearchViewController.h"
#import "CommonFunction.h"

@interface VOLoginViewController ()
{
    NSString *userID;
    NSString *deviceID;
    NSString *userTestID;
}
@end
@implementation VOLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if ([CommonFunction getSessionID] != nil) {
        [self successLogin];
        [AppDelegate sharedAppDelegate].savedUserID = [CommonFunction getUserID];
    }
}
- (void)viewWillAppear:(BOOL)animated
{
    userID = @"";
    deviceID = [CommonFunction getDeviceID];
    NSLog(@"TEST_UDID  = %@",deviceID);
    NSDate * now = [NSDate date];
    NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
    [outputFormatter setDateFormat:@"HH:mm:ss"];
    userTestID = [outputFormatter stringFromDate:now];
    NSLog(@"USERTESTID = %@",userTestID);

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)onFBLogin:(id)sender {
    if ([CommonFunction getSessionID] != nil) {
        [self successLogin];
        [AppDelegate sharedAppDelegate].savedUserID = [CommonFunction getUserID];
    }else{
        [self onFaceBookLogin];
    }
}

//////////Login via Facebook, Get Friend User, Creat_Vouch_User, Creat_Session//////////
- (void) onFaceBookLogin{
    FBSDKLoginManager * logIn = [[FBSDKLoginManager alloc] init];
    [logIn logInWithReadPermissions:@[@"public_profile", @"email", @"user_location", @"user_photos",@"user_friends"] fromViewController:self handler:^(FBSDKLoginManagerLoginResult *result , NSError *error){
        [[AppDelegate sharedAppDelegate] showWaitingScreen:@"Log in..." bShowText:YES withSize:CGSizeMake(150 * MULTIPLY_VALUE, 100 * MULTIPLY_VALUE)];
        if (error) {
            [[AppDelegate sharedAppDelegate] hideWaitingScreen];
            NSLog(@"Process error");
        }else if (result.isCancelled){
            [[AppDelegate sharedAppDelegate] hideWaitingScreen];
            NSLog(@"Cancelled");
        } else{
            NSLog(@"Loggedd in");
            NSLog(@"AccessToken =  %@",result.token);
            if ([FBSDKAccessToken currentAccessToken]) {
                ////////Login FaceBook////////
                [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:@{@"fields": @"picture.type(large), email, name, id, gender,age_range,birthday,location"}]
                 startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {

                     if (!error) {
                         
                         ///Get User Friends//////////
                         NSString *getUserQuery = [NSString stringWithFormat:@"/%@/%@",@"me",@"invitable_friends"];
                         FBSDKGraphRequest *friendGetRequest = [[FBSDKGraphRequest alloc]
                                                       initWithGraphPath:getUserQuery
                                                       parameters:nil
                                                       HTTPMethod:@"GET"];
                         [friendGetRequest startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection,
                                                               id friendresult,
                                                               NSError *frienderror) {
                             if (!frienderror) {
                                 NSLog(@"Friend_list Error %@",frienderror);
                                 NSLog(@"Friends_List =  %@",friendresult);
                                 NSArray *friendArray = [friendresult objectForKey:@"data"];
                                 NSMutableArray *friendStringArray = [NSMutableArray array];
                                 
                                 ///User_friends GET/////////////
                                 
                                 for (NSDictionary *theFriendInfoDic in friendArray)
                                 {
                                     NSString *tempStr = [NSString stringWithFormat:@"%@ = %@ = %@",theFriendInfoDic[@"id"],theFriendInfoDic[@"name"],theFriendInfoDic[@"picture"][@"data"][@"url"]];
                                     [friendStringArray addObject:tempStr];
                                  }
                                 /////////////////////////////////
                                 
                                 ///////USER_Model_make//////////
                                 NSDictionary *ageRangeDict = [result objectForKey:@"age_range"];
                                 NSString *age_range = [NSString stringWithFormat:@"%@-%@",
                                                       [ageRangeDict objectForKey:@"min"],
                                                       [ageRangeDict objectForKey:@"max"]];
                                 NSString *profile_url = result[@"picture"][@"data"][@"url"];
                                 NSString *gender = result[@"gender"];
                                 NSLog(@"RESULT = %@",result);
                                 [AppDelegate sharedAppDelegate].profile_picture_url = profile_url;
                                 NSDictionary *userModelDic = [[NSDictionary alloc] initWithObjectsAndKeys:
                                                               userTestID,USERID,
                                                               result[@"name"],USERNAME,
                                                               result[@"email"],USEREMAIL,
                                                               age_range,USER_AGE,
                                                               gender,USERGENDER,
                                                               profile_url,USERPROFILEIMGET,
                                                               friendStringArray,USERFRIENDS, nil];
                                 NSLog(@"USERMODEL = %@",userModelDic);
                                 ////////////////////////////////////
                                 
                                 ///////Creat_User////////////
                                 [ApiService creatUser:USER_CREAT_URI withJsonUserData:userModelDic withCompletion:^(BOOL succes_flag) {
                                     if (succes_flag == true) {
                                         NSLog(@"UserCreat :  OK");
                                         
                                         /////Creat_Session///////////
                                         [ApiService creatSession:USER_CREAT_SESSION_URI withUserID:userTestID withDeviceID:deviceID
                                                   withCompletion:^(SessionModel *sessionModel) {
                                                       [[AppDelegate sharedAppDelegate] hideWaitingScreen];
                                                       [self successLogin];
                                                       [CommonFunction saveUserID:userTestID];
                                                       [CommonFunction saveSessionID:sessionModel._id];
                                                   } failure:^(NSError *error) {
                                                       [[AppDelegate sharedAppDelegate] hideWaitingScreen];
                                                   }];
                                         
                                     }else{
                                         
                                         [[[UIAlertView alloc ] initWithTitle:@"" message:@"Login Failed!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
                                         NSLog(@"UserCreat :  NO");
                                         [[AppDelegate sharedAppDelegate] hideWaitingScreen];
                                     }
                                 } failure:^(NSError *error) {
                                     [[AppDelegate sharedAppDelegate] hideWaitingScreen];
                                     NSLog(@"%@",error);
                                 }];
                             }else{
                                 [[AppDelegate sharedAppDelegate] hideWaitingScreen];
                                 [[[UIAlertView alloc ] initWithTitle:@"" message:@"Network Connection Error90!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
                             }
                             // Handle the result
                         }];
                        

                     }else{
                         [[AppDelegate sharedAppDelegate] hideWaitingScreen];
                         [[[UIAlertView alloc ] initWithTitle:@"" message:@"Network Connection Error!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
                     }
                 }];
            }
            
            
        }
    }];

}
- (IBAction)onLogout:(id)sender {
    FBSDKLoginManager *loginManager = [[FBSDKLoginManager alloc] init];
    [loginManager logOut];
    [FBSDKAccessToken setCurrentAccessToken:nil];
    [CommonFunction resetDefaults];
}
- (void) successLogin{
    VOSearchViewController *searchViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"matchview"];
    [self.navigationController pushViewController:searchViewController animated:true];
}
@end
