//
//  VOMatchTableViewController.m
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "VOMatchTableViewController.h"
#import "VOMatchViewController.h"
#import "VOSearchViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>

@interface VOMatchTableViewController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation VOMatchTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _arrayURL.count;
};
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 110;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    MatchTableViewCell *customcell = [tableView dequeueReusableCellWithIdentifier:@"matchtablecell"];
    if (customcell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MatchTableViewCell" owner:self options:nil];
        customcell = [nib objectAtIndex:0];
    }
    customcell.imgPhoto.layer.backgroundColor=[[UIColor clearColor] CGColor];
    customcell.imgPhoto.layer.cornerRadius=customcell.imgPhoto.frame.size.width/2;
    customcell.imgPhoto.clipsToBounds = YES;
    customcell.imgPhoto.layer.borderColor=[[UIColor redColor] CGColor];
    [customcell.imgPhoto sd_setImageWithURL:[NSURL URLWithString:[[_arrayURL[indexPath.row] componentsSeparatedByString:@" = "] objectAtIndex:2]] placeholderImage:[UIImage imageNamed:@"samplephoto"]];
    customcell.lblName.text =[[_arrayURL[indexPath.row] componentsSeparatedByString:@" = "] objectAtIndex:1];
    customcell.lblMatchdata.text = @"Matched 2016/4/19";
    customcell.imgBuble.image = [UIImage imageNamed:@"imgBuble"];
    return customcell;
    
    
};

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:2] animated:YES];
}

#pragma mark BackBtn
- (IBAction)onBack:(id)sender {
    
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:2] animated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
