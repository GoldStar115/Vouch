//
//  MenuView.m
//  Vouch
//
//  Created by My Star on 5/25/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "MenuView.h"

@implementation MenuView
-(void)awakeFromNib {
    UIViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"Main"];
    if (controller != nil) {
        self.mainViewController = controller;
    }
    UIViewController *leftMenu = [self.storyboard instantiateViewControllerWithIdentifier:@"Left"];
    if (leftMenu != nil) {
        self.leftViewController = controller;
    }
    [super awakeFromNib];
}
@end
