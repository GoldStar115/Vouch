//
//  VODetailViewController.h
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VODetailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *btnBack;
@property NSString *urlString;
@property (weak, nonatomic) IBOutlet UIImageView *imgemainPhoto;
@property (weak, nonatomic) IBOutlet UIImageView *image_SUB1;
@property (weak, nonatomic) IBOutlet UIImageView *image_SUB2;
@property (weak, nonatomic) IBOutlet UIImageView *image_SUB3;
@property (weak, nonatomic) IBOutlet UIImageView *image_USSB4;
@property (weak, nonatomic) IBOutlet UILabel *lblname;

@property (weak, nonatomic) IBOutlet UILabel *lblAge;
@property NSArray *urlArray;
@end

