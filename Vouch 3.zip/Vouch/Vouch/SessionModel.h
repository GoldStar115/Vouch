//
//  SessionModel.h
//  Vouch
//
//  Created by My Star on 4/25/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import <JSONModel/JSONModel.h>

@interface SessionModel : JSONModel
@property NSNumber *__v;//": 0
@property NSString *user_id;//": "201139893595375"
@property NSString *device_id;//": "1"
@property NSString *last_action_time;//": "2016-04-25T07:16:25.891Z"
@property NSString *_id;//": "571dc44927983b1c00330902"
@property NSArray  *vouches;//": [0]
@end
