//
//  LeftMenuNavigationViewController.m
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "LeftMenuNavigationViewController.h"

@interface LeftMenuNavigationViewController ()

@end

@implementation LeftMenuNavigationViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

}

#pragma mark -
#pragma mark Gesture recognizer



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
