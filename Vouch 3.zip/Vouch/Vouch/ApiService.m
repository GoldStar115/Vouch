//
//  ApiService.m
//  Vouch
//
//  Created by My Star on 4/22/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "ApiService.h"
#import <JSONModel+networking.h>



@implementation ApiService

#pragma mark User
+ (void)creatUser:(NSString *)creatUserUri withJsonUserData:(NSDictionary *)userModel withCompletion:(void (^)(BOOL success_flag))completion  failure:(void (^)(NSError * error))failure
{
    NSString *creatUserUrl = [NSString stringWithFormat:@"%@%@",VOUCH_BASE_URL,USER_CREAT_URI];
    NSLog(@"%@",userModel);
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:creatUserUrl] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:20];
    [request setHTTPMethod:@"PUT"];
    
    NSError *error;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:userModel
                                                       options:NSJSONWritingPrettyPrinted error:&error];
    [request setHTTPMethod:@"PUT"];
    [request addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    // should check for and handle errors here but we aren't
    [request setHTTPBody:jsonData];
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithRequest:request completionHandler:^(NSData  *data, NSURLResponse  *response, NSError * error) {
        
        NSInteger statusCode = -1;        
        if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
            statusCode = [(NSHTTPURLResponse *)response statusCode];
            NSLog(@"%li",(long)statusCode);
            
        }
        if (statusCode == 200) {
            NSLog(@"%@", [[NSString alloc] initWithData:data encoding:NSStringEncodingConversionAllowLossy]);
            completion(true);
        } else {
            completion(false);
        }
        
    }] resume];


}

+ (void)getUser:(NSString *)getUserUri withUserID:(NSString *)userID withCompletion:(void (^)(UserModel *userModel))completion  failure:(void (^)(NSError * error))failure
{
    NSString *getUserUrl = [NSString stringWithFormat:@"%@%@/%@",VOUCH_BASE_URL,getUserUri,userID];
    [JSONHTTPClient getJSONFromURLWithString:getUserUrl
                                      params:nil
                                  completion:^(NSDictionary *json, JSONModelError *err) {
                                      if (!err) {
                                          NSLog(@"%@",json);
                                          UserModel *jsonModel = [[UserModel alloc] initWithDictionary:json error:nil];
                                          completion(jsonModel);
                                          NSLog(@"JSONMODEL =  %@",jsonModel);
                                      }else{
                                          NSLog(@"Error = %@",err);
                                      }

                                  }];
}

+ (void)userDelete:(NSString *)deleteUserUri withUserID:(NSString *)userID withCompletion:(void (^)(BOOL delete_flag))completion  failure:(void (^)(NSError * error))failure{
    NSString *deleteUserUrl = [NSString stringWithFormat:@"%@%@",VOUCH_BASE_URL,deleteUserUri];
    AFHTTPSessionManager *deleteManager = [[AFHTTPSessionManager alloc] init];
    [deleteManager DELETE:deleteUserUrl parameters:[NSDictionary dictionaryWithObject:userID forKey:USERID] success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        completion(true);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        completion(false);
    }];
}

#pragma mark Session
+ (void)creatSession:(NSString *)creatUserSessionUri withUserID:(NSString *)userID withDeviceID:(NSString *)deviceID withCompletion:(void (^)(SessionModel *sessionModel))completion  failure:(void (^)(NSError * error))failure{
    NSString *creatSessionURL = [NSString stringWithFormat:@"%@%@",VOUCH_BASE_URL,creatUserSessionUri];
    AFHTTPSessionManager *creatSessionManager = [[AFHTTPSessionManager alloc] init];
    [creatSessionManager PUT:creatSessionURL parameters:[NSDictionary dictionaryWithObjectsAndKeys:userID,@"user_id",
                                                                                                   deviceID,@"device_id" ,nil]
                     success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"%@",responseObject);
        SessionModel *sessionCreatModel = [[SessionModel alloc] initWithDictionary:responseObject error:nil];
        completion(sessionCreatModel);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"\n============== ERROR ====\n%@",error);
        
    }];
    
}


+ (void)updateSession:(NSString *)updateUserSessionUri withUserSessionID:(NSString *)userSessionID withCompletion:(void (^)(BOOL updateSessionFlag))completion  failure:(void (^)(NSError * error))failure{
    NSString *updateSessionURL = [NSString stringWithFormat:@"%@%@",VOUCH_BASE_URL,updateUserSessionUri];
    AFHTTPSessionManager *updateSessionManager = [[AFHTTPSessionManager alloc] init];
    [updateSessionManager POST:updateSessionURL parameters:[NSDictionary dictionaryWithObjectsAndKeys:userSessionID,@"session_id", nil] progress:^(NSProgress * _Nonnull uploadProgress) {        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        completion(true);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        completion(false);
    }];
    
}
+ (void)deleteSession:(NSString *)deleteUserSessionUri withUserSessionID:(NSString *)userSessionID withCompletion:(void (^)(BOOL updateSessionFlag))completion  failure:(void (^)(NSError * error))failure{
    NSString *deleteSessionURL = [NSString stringWithFormat:@"%@%@",VOUCH_BASE_URL,deleteUserSessionUri];
    AFHTTPSessionManager *deleteSessionManager = [[AFHTTPSessionManager alloc] init];
    [deleteSessionManager DELETE:deleteSessionURL parameters:[NSDictionary dictionaryWithObject:userSessionID forKey:@"session_id"] success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        completion(true);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        completion(false);
    }];
}

#pragma mark WaitingList

+ (void)creatwaitingList:(NSString *)waitingListUri withUserEmail:(NSString *)userEmail withCompletion:(void (^)(BOOL waitinglistSuccess_flag))completion  failure:(void (^)(NSError * error))failure{
    NSString *waitingListURL = [NSString stringWithFormat:@"%@%@",VOUCH_BASE_URL,waitingListUri];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:waitingListURL] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:20];
    NSError *error;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:[NSDictionary dictionaryWithObjectsAndKeys:userEmail,@"email", nil]
                                                       options:NSJSONWritingPrettyPrinted error:&error];
    [request setHTTPMethod:@"PUT"];
    [request addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    // should check for and handle errors here but we aren't
    [request setHTTPBody:jsonData];
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithRequest:request completionHandler:^(NSData  *data, NSURLResponse  *response, NSError * error) {
        
        NSInteger statusCode = -1;
        if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
            statusCode = [(NSHTTPURLResponse *)response statusCode];
            NSLog(@"%li",(long)statusCode);
            
        }
        if (statusCode == 200) {
            NSLog(@"%@", [[NSString alloc] initWithData:data encoding:NSStringEncodingConversionAllowLossy]);
            completion(true);
        } else {
            completion(false);
        }
        
    }] resume];
    
}
+ (void)deletewaitingList:(NSString *)waitingListUri withUserEmail:(NSString *)userEmail withCompletion:(void (^)(BOOL waitinglistSuccess_flag))completion  failure:(void (^)(NSError * error))failure{
    NSString *deletewaitingListURL = [NSString stringWithFormat:@"%@%@",VOUCH_BASE_URL,waitingListUri];
    AFHTTPSessionManager *deleteWaitingManager = [[AFHTTPSessionManager alloc] init];
    [deleteWaitingManager DELETE:deletewaitingListURL parameters:[NSDictionary dictionaryWithObject:userEmail forKey:@"email"] success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        completion(true);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        completion(false);
    }];
    
}

#pragma mark vouches

+ (void)getVouchUser:(NSString *)getVouchUri withUserID:(NSString *)userID withCompletion:(void (^)(NSString * vouchUserID))completion  failure:(void (^)(NSError * error))failure{
    NSString *getVouchURL = [NSString stringWithFormat:@"%@%@/%@",VOUCH_BASE_URL,@"vouches",userID];
    AFHTTPSessionManager *getVouchmanager = [AFHTTPSessionManager manager];
    [getVouchmanager GET:getVouchURL parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSLog(@"JSON: %@", responseObject);
        completion(responseObject);
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}
+ (void)updateVouchUser:(NSString *)postVouchUri withSessinID:(NSString *) giverSessionID withReceiverUserID :(NSString *)receiverUserID withCompletion:(void (^)(NSString * vouchUserID))completion  failure:(void (^)(NSError * error))failure{
    NSString *updateVouchURL = [NSString stringWithFormat:@"%@%@",VOUCH_BASE_URL,postVouchUri];
    AFHTTPSessionManager *updateVouchManager = [[AFHTTPSessionManager alloc] init];
    [updateVouchManager POST:updateVouchURL parameters:[NSDictionary dictionaryWithObjectsAndKeys:giverSessionID,@"giver_session_id",receiverUserID,@"receiver_user_id", nil] progress:^(NSProgress * _Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        completion(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        completion(false);
    }];
}

#pragma mark Like
+ (void)postLikeUser:(NSString *)postLikeUri withLikerID:(NSString *)likerId withLikedID:(NSString *)likedId withCompletion:(void (^)(BOOL match_flag))completion  failure:(void (^)(NSError * error))failure{
    NSString *userlikeURL = [NSString stringWithFormat:@"%@%@",VOUCH_BASE_URL,postLikeUri];
    AFHTTPSessionManager *postlikeManager = [[AFHTTPSessionManager alloc] init];
    [postlikeManager POST:userlikeURL parameters:[NSDictionary dictionaryWithObjectsAndKeys:likerId,@"likerId",likerId,@"likerId", nil] progress:^(NSProgress * _Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        completion(true);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        completion(false);
    }];
}

#pragma mark ratings
+ (void)postRatingsUser:(NSString *)postRatingUri withUserID:(NSString *)user_id withRating:(NSString *)rating withCompletion:(void (^)(BOOL rating_flag))completion  failure:(void (^)(NSError * error))failure{
    NSString *userRatingURL = [NSString stringWithFormat:@"%@%@",VOUCH_BASE_URL,postRatingUri];
    AFHTTPSessionManager *postRatingManager = [[AFHTTPSessionManager alloc] init];
    [postRatingManager POST:userRatingURL parameters:[NSDictionary dictionaryWithObjectsAndKeys:user_id,@"user_id",rating,@"rating", nil] progress:^(NSProgress * _Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        completion(true);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        completion(false);
    }];
}
@end
