//
//  ViewController.h
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VOLoginViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *btnFBLogin;
@property (weak, nonatomic) IBOutlet UIImageView *portrait;


@end

