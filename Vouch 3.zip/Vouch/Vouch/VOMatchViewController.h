//
//  VOMatchViewController.h
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VOMatchViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *txtSearch;
@property (weak, nonatomic) IBOutlet UIButton *btnBackMatch;
@property (weak, nonatomic) IBOutlet UIImageView *imgMainPhoto;
@property (weak, nonatomic) IBOutlet UILabel *labMainName;
@property (weak, nonatomic) IBOutlet UILabel *lblMainAge;
@property (weak, nonatomic) IBOutlet UITextField *txtVouchSearch;
@property (weak, nonatomic) IBOutlet UIImageView *btnSearch;
@property (weak, nonatomic) IBOutlet UIButton *btnSearchView;
@property (weak, nonatomic) IBOutlet UIButton *btnBack;
@property (weak, nonatomic) IBOutlet UIButton *btnVouchRequest;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;



@property NSMutableArray *friendListArray;
@end
