//
//  SessionModel.m
//  Vouch
//
//  Created by My Star on 4/25/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "SessionModel.h"

@implementation SessionModel

@end
