//
//  MatchTableViewCell.h
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MatchTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgPhoto;
@property (weak, nonatomic) IBOutlet UIImageView *imgBuble;
@property (weak, nonatomic) IBOutlet UILabel *lblName;
@property (weak, nonatomic) IBOutlet UILabel *lblMatchdata;

@end
