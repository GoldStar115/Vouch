//
//  VODetailViewController.m
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "VODetailViewController.h"
#import <SDWebImage/UIImageView+HighlightedWebCache.h>
#import <SDWebImage/UIImageView+WebCache.h>
#import "VOMatchTableViewController.h"

@interface VODetailViewController ()

@end

@implementation VODetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (void)viewWillAppear:(BOOL)animated
{
     NSLog(@"%@",_urlArray[0]);
    NSString *imageURL = [[_urlArray[0] componentsSeparatedByString:@" = "] objectAtIndex:2];
   
//    _lblVouchesNumber.text = [NSString stringWithFormat:@"%d",(int)_arrayVouchs.count];
    [_imgemainPhoto sd_setImageWithURL:[NSURL URLWithString:imageURL] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        if (!error) {
            _imgemainPhoto.image = image;
           [ _image_SUB1 sd_setImageWithURL:[NSURL URLWithString:[[_urlArray[1] componentsSeparatedByString:@" = "] objectAtIndex:2]] placeholderImage:[UIImage imageNamed:@"samplephoto"]];
            [ _image_SUB2 sd_setImageWithURL:[NSURL URLWithString:[[_urlArray[2] componentsSeparatedByString:@" = "] objectAtIndex:2]
                                              ] placeholderImage:[UIImage imageNamed:@"samplephoto"]];
            [ _image_SUB3 sd_setImageWithURL:[NSURL URLWithString:[[_urlArray[3] componentsSeparatedByString:@" = "] objectAtIndex:2]
                                              ] placeholderImage:[UIImage imageNamed:@"samplephoto"]];
            [ _image_USSB4 sd_setImageWithURL:[NSURL URLWithString:[[_urlArray[4] componentsSeparatedByString:@" = "] objectAtIndex:2]
                                              ] placeholderImage:[UIImage imageNamed:@"samplephoto"]];
        }else{
            
        }
    }];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)onBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)onVouchesList:(id)sender {
    VOMatchTableViewController *matchTableViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"matchViewController"];
    matchTableViewController.arrayURL = [NSMutableArray array];
    matchTableViewController.arrayURL = _urlArray;
    [self.navigationController pushViewController:matchTableViewController animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
