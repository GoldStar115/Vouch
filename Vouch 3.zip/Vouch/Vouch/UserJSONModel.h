//
//  UserJSONModel.h
//  Vouch
//
//  Created by My Star on 4/23/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import <JSONModel/JSONModel.h>
#import "UserModel.h"

@interface UserJSONModel : JSONModel

//@property NSArray<UserModel>* loans;
//@property NSArray<UserModel>* userModel;


@end
