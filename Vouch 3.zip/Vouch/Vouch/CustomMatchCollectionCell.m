//
//  CustomMatchCollectionCell.m
//  Vouch
//
//  Created by My Star on 4/26/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "CustomMatchCollectionCell.h"

@implementation CustomMatchCollectionCell

@end
