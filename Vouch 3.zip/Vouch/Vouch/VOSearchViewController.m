//
//  VOSearchViewController.m
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "VOSearchViewController.h"
#import "VOLoginViewController.h"
#import "AppDelegate.h"
#import "SlideNavigationController.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "UIImage+ImageEffects.h"
#import "VODetailViewController.h"
#import "VOMatchTableViewController.h"

@interface VOSearchViewController ()

@end

@implementation VOSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGestureRecognized:)]];
}
- (void)viewWillAppear:(BOOL)animated
{
    NSString *imageURL = [[_arrayVouchs[0] componentsSeparatedByString:@" = "] objectAtIndex:2];
    _lblVouchesNumber.text = [NSString stringWithFormat:@"%d",(int)_arrayVouchs.count];
    [_imageBackground.image applyLightEffect];
    [_imageLikePhoto sd_setImageWithURL:[NSURL URLWithString:imageURL] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        if (!error) {
            _imageBackground.image = [UIImage imageNamed:@"background"];
            _imageLikePhoto.image = image;
        }else{
            
        }
    }];
}
- (void)panGestureRecognized:(UIPanGestureRecognizer *)sender
{
    // Dismiss keyboard (optional)
    //
    [self.view endEditing:YES];
    [self.frostedViewController.view endEditing:YES];
    
    // Present the view controller
    //
    [self.frostedViewController panGestureRecognized:sender];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)onLeftMenu:(id)sender {
    [self.view endEditing:YES];
    [[SlideNavigationController sharedInstance] leftMenuSelected:nil];

        // Dismiss keyboard (optional)
        //
        [self.view endEditing:YES];
//        [self.frostedViewController.view endEditing:YES];
//        
//        // Present the view controller
//        //
//        [self.frostedViewController presentMenuViewController];
   
}
- (IBAction)onLike:(id)sender {
    [self getAllVouches];
    
}
-(void)getAllVouches {
    VODetailViewController *detailviewController =  [self.storyboard instantiateViewControllerWithIdentifier:@"detailview"];
    detailviewController.urlString = [[_arrayVouchs[0] componentsSeparatedByString:@" = "] objectAtIndex:2];
    
    detailviewController.urlArray = [NSMutableArray array];
    detailviewController.urlArray = [NSArray arrayWithArray:_arrayVouchs];
    [self.navigationController pushViewController:detailviewController animated:YES];
}
- (IBAction)onDislike:(id)sender {
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:1] animated:YES];
}
- (IBAction)onGetAllVouches:(id)sender {
    [self getAllVouches];
}
- (IBAction)onShowVouchList:(id)sender {
    VOMatchTableViewController *matchTableViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"matchViewController"];
    matchTableViewController.arrayURL = [NSMutableArray array];
    matchTableViewController.arrayURL = _arrayVouchs;
    [self.navigationController pushViewController:matchTableViewController animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
