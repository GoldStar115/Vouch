//
//  UserModel.m
//  Vouch
//
//  Created by My Star on 4/22/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "UserModel.h"

@implementation UserModel

@end
