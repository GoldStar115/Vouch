//
//  MenuViewController.h
//  Vouch
//
//  Created by My Star on 4/19/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NMRangeSlider.h"

@interface MenuViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imagePhoto1;
@property (weak, nonatomic) IBOutlet UIImageView *imageSubPhoto2;
@property (weak, nonatomic) IBOutlet UIImageView *imageSubPhoto3;
@property (weak, nonatomic) IBOutlet UIImageView *imagesubPhoto4;
@property (weak, nonatomic) IBOutlet NMRangeSlider *SliderAgeRange;

@end
