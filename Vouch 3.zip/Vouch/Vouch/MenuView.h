//
//  MenuView.h
//  Vouch
//
//  Created by My Star on 5/25/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import <SlideMenuControllerOC/SlideMenuController.h>


@interface MenuView : SlideMenuController

@end
