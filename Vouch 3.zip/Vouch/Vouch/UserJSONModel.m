//
//  UserJSONModel.m
//  Vouch
//
//  Created by My Star on 4/23/16.
//  Copyright © 2016 Vouch. All rights reserved.
//

#import "UserJSONModel.h"
@implementation UserJSONModel

@end